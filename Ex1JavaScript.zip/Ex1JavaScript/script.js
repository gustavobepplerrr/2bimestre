let inputnum1 = document.querySelector("#inputnum1");
let inputnum2 = document.querySelector("#inputnum2");
let btSomar = document.querySelector("#btSomar");
let h3resultado = document.querySelector("#h3resultado");
    function somarNumero(){

        let num1 = Number(inputnum1.value);
        let num2 = Number(inputnum2.value);

        h3resultado.textContent = (num1 + num2);

    }

btSomar.onclick = function(){
     somarNumero();
}
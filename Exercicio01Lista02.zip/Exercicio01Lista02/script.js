let inputNum = document.querySelector("#inputNum");
let btReajuste = document.querySelector("#btReajuste");
let Resultado1 = document.querySelector("#Resultado1");

function reajustarNumeros() {
    // Verifica se os elementos DOM existem
    if (!inputNum || !btReajuste || !Resultado1) {
        console.error("Elementos DOM não encontrados.");
        return;
    }

    // Obtém o valor do input e calcula o aumento de 1%
    let Num = Number(inputNum.value);
    if (isNaN(Num)) {
        console.error("Valor inválido.");
        return;
    }

    let Res1 = Num * (1 / 100);
    Resultado1.textContent = `Valor com aumento de 1%: R$ ${(Num + Res1).toFixed(2)}`;
}

btReajuste.onclick = function() {
    reajustarNumeros();
};

let comprimento = document.querySelector("#comprimento");
let largura = document.querySelector("#largura");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function areaNum(){

    let num1 = Number(comprimento.value);
    let num2 = Number(largura.value);


    resultado.textContent = num1 * num2;

}

btCalcular.onclick = function(){

    areaNum();
}
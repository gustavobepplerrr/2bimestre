let cavalos = document.querySelector("#cavalos");
let btCalcular = document.querySelector("#btCalcular");
let resultado = document.querySelector("#resultado");

function ferraduras(){

    let num1 = Number(cavalos.value);

    resultado.textContent = num1 * 4;
}

btCalcular.onclick = function(){

    ferraduras()
};
let inputNum1 = document.querySelector("#inputnum1");
let inputNum2 = document.querySelector("#inputNum2");
let btCalcular = document.querySelector("#btCalcular");
let resultado1 = document.querySelector("#resultado1");
let resultado2 = document.querySelector("#resultado2");
let resultado3 = document.querySelector("#resultado3");
let resultado4 = document.querySelector("#resultado4");

function resultados(){

    let = num1 = Number(inputNum1.value);
    let = num2 = Number(inputNum2.value);

    resultado1.textContent = (num1 + num2);

    resultado2.textContent = (num1 - num2);

    resultado3.textContent = (num1 * num2);

    resultado4.textContent = (num1 / num2);


}

btCalcular.onclick = function(){
    resultados();
}
document.getElementById('vendasForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const precoPao = 0.12;
    const precoBroa = 1.50;

    const qtdPaes = parseInt(document.getElementById('paes').value);
    const qtdBroas = parseInt(document.getElementById('broas').value);

    const totalArrecadado = (qtdPaes * precoPao) + (qtdBroas * precoBroa);
    const poupanca = totalArrecadado * 0.10;

    document.getElementById('total').textContent = `R$ ${totalArrecadado.toFixed(2)}`;
    document.getElementById('poupanca').textContent = `R$ ${poupanca.toFixed(2)}`;

    document.getElementById('result').style.display = 'block';
});

function calcularTotal() {
    // Valores fixos
    const precoPizza = 12.00;
    const precoRefrigerante = 7.00;

    const sabor1 = document.getElementById('sabor1').value;
    const sabor2 = document.getElementById('sabor2').value;
    const sabor3 = document.getElementById('sabor3').value;
    const sabor4 = document.getElementById('sabor4').value;
    const quantidadeRefrigerantes = parseInt(document.getElementById('quantidadeRefrigerantes').value);

    const totalPizzas = 4 * precoPizza;
    const totalRefrigerantes = quantidadeRefrigerantes * precoRefrigerante;
    const total = totalPizzas + totalRefrigerantes;

    const resumo = `Sabores escolhidos: ${sabor1}, ${sabor2}, ${sabor3}, ${sabor4}.`;
    const valorTotal = `Valor total a pagar: R$ ${total.toFixed(2)}`;

    document.getElementById('resumo').innerText = resumo;
    document.getElementById('valorTotal').innerText = valorTotal;
  }
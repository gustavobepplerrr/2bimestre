function calcularDias() {
    const nome = document.getElementById("nome").value.trim();
    const idade = parseInt(document.getElementById("idade").value);
    const resultado = document.getElementById("resultado");
  
    if (nome === "" || isNaN(idade)) {
      resultado.textContent = "Preencha os dois campos corretamente.";
      return;
    }
  
    const dias = idade * 365;
    resultado.textContent = `${nome.toUpperCase()}, VOCE JA VIVEU ${dias} DIAS`;
  }
  
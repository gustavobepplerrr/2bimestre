function calcularLitros() {
    const preco = parseFloat(document.getElementById('preco').value);
    const valor = parseFloat(document.getElementById('valor').value);
    const saida = document.getElementById('saida');
  
    if (isNaN(preco) || isNaN(valor) || preco <= 0) {
      saida.textContent = "Preencha corretamente os valores.";
      return;
    }
  
    const litros = valor / preco;
    saida.textContent = `Voce abasteceu ${litros.toFixed(2)} litros.`;
  }
  
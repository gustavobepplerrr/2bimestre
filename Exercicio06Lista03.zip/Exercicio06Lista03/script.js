function calcularValor() {
    const peso = parseFloat(document.getElementById('peso').value);
    const resposta = document.getElementById('resposta');
  
    if (isNaN(peso) || peso <= 0) {
      resposta.textContent = "Informe um peso valido.";
      return;
    }
  
    const precoPorQuilo = 12.00;
    const total = peso * precoPorQuilo;
  
    resposta.textContent = `O valor a pagar e R$ ${total.toFixed(2)}.`;
  }
  
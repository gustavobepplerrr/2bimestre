function mostrarMaior() {
    const v1 = parseFloat(document.getElementById('valor1').value);
    const v2 = parseFloat(document.getElementById('valor2').value);
    const resultado = document.getElementById('resultado');
  
    if (isNaN(v1) || isNaN(v2)) {
      resultado.textContent = "Por favor, insira dois valores numericos validos.";
      return;
    }
  
    if (v1 === v2) {
      resultado.textContent = "Os dois valores sao iguais.";
      return;
    }
  
    const maior = v1 > v2 ? v1 : v2;
    resultado.textContent = `O maior valor e ${maior}.`;
  }
  
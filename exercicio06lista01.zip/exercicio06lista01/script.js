function mostrarMenor() {
    const valores = [
      parseFloat(document.getElementById('valor1').value),
      parseFloat(document.getElementById('valor2').value),
      parseFloat(document.getElementById('valor3').value),
      parseFloat(document.getElementById('valor4').value)
    ];
    const resultado = document.getElementById('resultado');
  
    // Verifica se todos são números válidos
    if (valores.some(v => isNaN(v))) {
      resultado.textContent = "Por favor, insira quatro valores numericos validos.";
      return;
    }
  
    const menor = Math.min(...valores);
    resultado.textContent = `O menor valor e ${menor}.`;
  }
  
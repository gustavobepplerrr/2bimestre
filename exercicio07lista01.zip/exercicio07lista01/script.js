function verificarImpar() {
    const valorInput = document.getElementById('valor').value;
    const resultado = document.getElementById('resultado');
    const valor = parseInt(valorInput);
  
    if (isNaN(valor)) {
      resultado.textContent = "Por favor, insira um numero valido.";
      return;
    }
  
    if (valor % 2 !== 0) {
      resultado.textContent = `O numero ${valor} e impar.`;
    } else {
      resultado.textContent = `O numero ${valor} nao e impar.`;
    }
  }
  
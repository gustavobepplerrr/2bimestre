function contarDias() {
    const mes = parseInt(document.getElementById('mes').value);
    const dia = parseInt(document.getElementById('dia').value);
    const saida = document.getElementById('saida');
  
    if (isNaN(mes) || isNaN(dia) || mes < 1 || mes > 12 || dia < 1 || dia > 30) {
      saida.textContent = "Informe uma data valida.";
      return;
    }
  
    const diasPassados = (mes - 1) * 30 + dia;
    saida.textContent = `Ja se passaram ${diasPassados} dias desde o inicio do ano.`;
  }
  
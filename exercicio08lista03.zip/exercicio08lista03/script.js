function calcularVenda() {
    const pequenas = parseInt(document.getElementById('peq').value) || 0;
    const medias = parseInt(document.getElementById('med').value) || 0;
    const grandes = parseInt(document.getElementById('grd').value) || 0;
    const resposta = document.getElementById('resposta');
  
    const total = (pequenas * 10) + (medias * 12) + (grandes * 15);
  
    resposta.textContent = `Valor total arrecadado: R$ ${total.toFixed(2)}`;
  }
  
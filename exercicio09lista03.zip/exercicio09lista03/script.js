function calcularDistancia() {
    const x1 = parseFloat(document.getElementById('x1').value);
    const y1 = parseFloat(document.getElementById('y1').value);
    const x2 = parseFloat(document.getElementById('x2').value);
    const y2 = parseFloat(document.getElementById('y2').value);
    const saida = document.getElementById('saida');
  
    if ([x1, y1, x2, y2].some(isNaN)) {
      saida.textContent = "Preencha todos os campos com numeros validos.";
      return;
    }
  
    const dx = x2 - x1;
    const dy = y2 - y1;
    const distancia = Math.sqrt(dx * dx + dy * dy);
  
    saida.textContent = `Distancia: ${distancia.toFixed(2)}`;
  }
  
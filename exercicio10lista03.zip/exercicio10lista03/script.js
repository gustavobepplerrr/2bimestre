function converterTempo() {
    const totalDias = parseInt(document.getElementById('dias').value);
    const resultado = document.getElementById('resultado');
  
    if (isNaN(totalDias) || totalDias < 0) {
      resultado.textContent = "Digite um número valido de dias.";
      return;
    }
  
    const anos = Math.floor(totalDias / 360);
    const meses = Math.floor((totalDias % 360) / 30);
    const dias = totalDias % 30;
  
    resultado.textContent = `Tempo sem acidentes: ${anos} ano(s), ${meses} mes(es), ${dias} dia(s).`;
  }
  
function calcularReajuste() {
    const salarioInput = document.getElementById('salario').value;
    const resultado = document.getElementById('resultado');
    const salario = parseFloat(salarioInput);
  
    if (isNaN(salario) || salario <= 0) {
      resultado.textContent = "Informe um salario valido.";
      return;
    }
  
    const aumento = salario * 0.15;
    const salarioComAumento = salario + aumento;
    const imposto = salarioComAumento * 0.08;
    const salarioFinal = salarioComAumento - imposto;
  
    resultado.innerHTML = `
      Salario inicial: R$ ${salario.toFixed(2)}<br>
      Salario com aumento (15%): R$ ${salarioComAumento.toFixed(2)}<br>
      Salario final (com 8% de imposto): R$ ${salarioFinal.toFixed(2)}
    `;
  }
  
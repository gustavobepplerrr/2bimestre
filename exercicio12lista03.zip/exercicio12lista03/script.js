function separarDigitos() {
    let num = document.getElementById('numero').value;
    const resultado = document.getElementById('resultado');
  
    num = num.trim();
  
    if (!/^\d{1,3}$/.test(num)) {
      resultado.textContent = "Digite um numero inteiro entre 0 e 999.";
      return;
    }
  
    // Convertendo para número inteiro
    const numero = parseInt(num);
  
    const centena = Math.floor(numero / 100);
    const dezena = Math.floor((numero % 100) / 10);
    const unidade = numero % 10;
  
    resultado.textContent = 
  `CENTENA = ${centena}
  DEZENA = ${dezena}
  UNIDADE = ${unidade}`;
  }
  
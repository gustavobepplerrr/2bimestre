function calcularArea() {
    const raioInput = document.getElementById('raio').value;
    const resultado = document.getElementById('resultado');
    const raio = parseFloat(raioInput);
    const PI = 3.14;
  
    if (isNaN(raio) || raio <= 0) {
      resultado.textContent = "Informe um valor válido para o raio.";
      return;
    }
  
    const area = PI * (raio ** 2);
    resultado.textContent = `Área da pizza: ${area.toFixed(2)} unidades².`;
  }
  
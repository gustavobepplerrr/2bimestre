function dividirConta() {
    const totalStr = document.getElementById('total').value;
    const resultado = document.getElementById('resultado');
    const total = parseFloat(totalStr);
  
    if (isNaN(total) || total <= 0) {
      resultado.textContent = "Informe um valor valido para a conta.";
      return;
    }
  
    const valorParcial = Math.floor((total / 3) * 100) / 100;
  
    const carlos = valorParcial;
    const andre = valorParcial;
  
    const felipe = total - (carlos + andre);
  
    resultado.innerHTML = `
      Carlos: R$ ${carlos.toFixed(2)}<br>
      Andre: R$ ${andre.toFixed(2)}<br>
      Felipe: R$ ${felipe.toFixed(2)}
    `;
  }
  